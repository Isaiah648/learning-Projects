A "card" that is about me and designed with HTML and CSS for Bits of Good bootcamp application.
